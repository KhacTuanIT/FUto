#ifndef _DEFS_H
#define _DEFS_H

typedef unsigned long DWORD;
typedef unsigned long *PDWORD;
typedef unsigned short WORD;
typedef unsigned char BYTE;
typedef unsigned char *PBYTE;
typedef unsigned short HMODULE;


#endif